package com.rtxsmartt.client

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rtxsmartt.client.data.*
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

data class UiState(
    val configured: Boolean = false, val loading: Boolean = false, val error: String? = null,
    val config: ConfigDto? = null, val dns: List<DnsDto> = emptyList(), val ads: List<AdDto> = emptyList(),
    val notes: List<NoteDto> = emptyList(), val sports: SportsDto? = null, val update: UpdateDto? = null,
    val latency: Map<String, Long> = emptyMap(), val selectedDns: String = "", val updateMessage: String? = null,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    private val http = OkHttpClient.Builder().connectTimeout(10, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
    private val pingHttp = OkHttpClient.Builder().connectTimeout(5, TimeUnit.SECONDS).readTimeout(5, TimeUnit.SECONDS).build()
    private val _state = MutableStateFlow(UiState(configured = store.baseUrl.isNotBlank() && store.apiKey.isNotBlank(), selectedDns = store.selectedDns))
    val state: StateFlow<UiState> = _state

    init { if (_state.value.configured) refresh() }

    private fun normalize(u: String): String = u.trim().trimEnd('/').removeSuffix("/api/v1").removeSuffix("/api").trimEnd('/')

    fun setup(url: String, key: String, onResult: (String?) -> Unit) {
        val base = normalize(url); val k = key.trim()
        if (!base.startsWith("https://")) { onResult("The panel URL must start with https://"); return }
        if (k.isEmpty()) { onResult("Enter the API key"); return }
        viewModelScope.launch {
            try {
                Api(base, k, http).config()
                store.baseUrl = base; store.apiKey = k
                _state.update { it.copy(configured = true) }; refresh(); onResult(null)
            } catch (e: ApiException) { onResult(e.message) } catch (e: Exception) { onResult("Cannot reach the panel: ${e.message}") }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            try {
                val api = Api(store.baseUrl, store.apiKey, http)
                coroutineScope {
                    val c = async { api.config() }; val d = async { api.dns() }; val a = async { api.ads() }
                    val n = async { api.notes() }; val s = async { api.sports() }; val u = async { api.update() }
                    _state.update { it.copy(config = c.await(), dns = d.await(), ads = a.await(), notes = n.await(), sports = s.await(), update = u.await(), loading = false) }
                }
            } catch (e: ApiException) {
                _state.update { it.copy(loading = false, error = e.message) }
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, error = "Connection problem: ${e.message}") }
            }
        }
    }

    fun selectDns(url: String) { store.selectedDns = url; _state.update { it.copy(selectedDns = url) } }

    fun ping(url: String) {
        viewModelScope.launch {
            val ms = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                val t = System.nanoTime()
                try { pingHttp.newCall(Request.Builder().url(url).head().build()).execute().close(); (System.nanoTime() - t) / 1_000_000 } catch (e: Exception) { -1L }
            }
            _state.update { it.copy(latency = it.latency + (url to ms)) }
        }
    }

    fun installUpdate(ctx: android.content.Context) {
        val u = _state.value.update ?: return
        viewModelScope.launch {
            _state.update { it.copy(updateMessage = "Downloading…") }
            val err = Updater.downloadAndInstall(ctx, http, store.apiKey, u)
            _state.update { it.copy(updateMessage = err) }
        }
    }

    fun logout() { store.clear(); _state.value = UiState() }
}
