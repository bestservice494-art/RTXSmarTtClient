package com.rtxsmartt.client.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request

class ApiException(val code: Int) : Exception(
    when (code) { 401 -> "Invalid or revoked API key"; 403 -> "Key not allowed"; 429 -> "Too many requests, try again later"; else -> "Server error ($code)" }
)

val JSON = Json { ignoreUnknownKeys = true; coerceInputValues = true }

/** REST v1 client. The application is identified by the key only. */
class Api(baseUrl: String, private val key: String, private val http: OkHttpClient) {
    private val root = baseUrl.trimEnd('/') + "/api/v1/"
    private suspend fun get(path: String): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(root + path).header("Authorization", "Bearer $key").header("Accept", "application/json").build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw ApiException(r.code)
            r.body?.string() ?: throw ApiException(500)
        }
    }
    suspend fun config() = JSON.decodeFromString<Envelope<ConfigDto>>(get("config")).data
    suspend fun dns() = JSON.decodeFromString<Envelope<List<DnsDto>>>(get("dns")).data
    suspend fun ads() = JSON.decodeFromString<Envelope<List<AdDto>>>(get("ads")).data
    suspend fun notes() = JSON.decodeFromString<Envelope<List<NoteDto>>>(get("notes")).data
    suspend fun sports() = JSON.decodeFromString<Envelope<SportsDto>>(get("sports")).data
    suspend fun update() = JSON.decodeFromString<Envelope<UpdateDto>>(get("updates/latest")).data
}
