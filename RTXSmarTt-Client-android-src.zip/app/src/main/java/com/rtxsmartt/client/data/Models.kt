package com.rtxsmartt.client.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonPrimitive

/** Numbers/booleans arrive as JsonPrimitive so both 1 and "1" (or true) are accepted. */
fun JsonPrimitive?.int(): Int = this?.content?.toIntOrNull() ?: 0
fun JsonPrimitive?.bool(): Boolean = this?.content.let { it == "true" || it == "1" }

@Serializable data class Envelope<T>(val data: T)

@Serializable data class ConfigDto(
    val name: String? = null,
    @SerialName("package") val pkg: String? = null,
    @SerialName("current_version") val currentVersion: String? = null,
    @SerialName("min_version") val minVersion: String? = null,
    @SerialName("logo_url") val logoUrl: String? = null,
    @SerialName("background_url") val backgroundUrl: String? = null,
    @SerialName("intro_video_url") val introVideoUrl: String? = null,
    @SerialName("rate_url") val rateUrl: String? = null,
)

@Serializable data class DnsDto(
    val id: JsonPrimitive? = null, val title: String = "", val url: String = "", val description: String? = null,
    @SerialName("is_default") val isDefault: JsonPrimitive? = null,
)

@Serializable data class AdDto(
    val id: JsonPrimitive? = null, val title: String = "", val type: String = "external", val url: String = "", val category: String? = null,
    @SerialName("duration_seconds") val durationSeconds: JsonPrimitive? = null,
)

@Serializable data class NoteDto(
    val id: JsonPrimitive? = null, val title: String = "", val body: String? = null, val category: String? = null,
    @SerialName("is_pinned") val isPinned: JsonPrimitive? = null, @SerialName("updated_at") val updatedAt: String? = null,
)

@Serializable data class SportsSettings(
    @SerialName("header_n") val header: String? = null, @SerialName("border_c") val border: String? = null,
    @SerialName("background_c") val background: String? = null, @SerialName("text_c") val text: String? = null,
    val days: JsonPrimitive? = null, @SerialName("auto_s") val auto: JsonPrimitive? = null,
)
@Serializable data class SportsLink(val category: String? = null, val title: String = "", val url: String = "")
@Serializable data class SportsDto(val settings: SportsSettings? = null, val links: List<SportsLink> = emptyList())

@Serializable data class UpdateDto(
    val available: Boolean = false,
    @SerialName("version_name") val versionName: String? = null,
    @SerialName("version_code") val versionCode: JsonPrimitive? = null,
    @SerialName("package") val pkg: String? = null,
    @SerialName("release_notes") val notes: String? = null,
    @SerialName("min_supported_version") val minSupported: String? = null,
    val mandatory: JsonPrimitive? = null,
    @SerialName("download_url") val downloadUrl: String? = null,
    val sha256: String? = null,
    @SerialName("size_bytes") val sizeBytes: JsonPrimitive? = null,
)
