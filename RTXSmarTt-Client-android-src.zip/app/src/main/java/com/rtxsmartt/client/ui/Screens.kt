package com.rtxsmartt.client.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.rtxsmartt.client.BuildConfig
import com.rtxsmartt.client.MainViewModel
import com.rtxsmartt.client.UiState
import com.rtxsmartt.client.data.*
import kotlinx.coroutines.delay

private val Purple = Color(0xFF8B5CF6)
private val Blue = Color(0xFF3B82F6)
private val Cyan = Color(0xFF22D3EE)
private val Bg = Color(0xFF0B0C14)
private val Panel = Color(0xFF141626)

@Composable fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, secondary = Blue, tertiary = Cyan, background = Bg, surface = Panel, onBackground = Color(0xFFE7E9F5), onSurface = Color(0xFFE7E9F5)), content = content)
}

private fun openUrl(ctx: android.content.Context, url: String) {
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

@Composable fun Root(vm: MainViewModel) {
    val st by vm.state.collectAsStateWithLifecycle()
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        if (!st.configured) SetupScreen(vm) else MainScreen(vm, st)
    }
}

@Composable fun SetupScreen(vm: MainViewModel) {
    var url by remember { mutableStateOf("") }; var key by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("RTXSmarTt", style = MaterialTheme.typography.headlineLarge, color = Purple)
        Spacer(Modifier.height(8.dp))
        Text("Enter the panel address and the API key created in API Management.", color = Color(0xFF8A90B0))
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(url, { url = it }, label = { Text("Panel URL (https://…)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(key, { key = it }, label = { Text("API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        err?.let { Spacer(Modifier.height(8.dp)); Text(it, color = Color(0xFFEF4444)) }
        Spacer(Modifier.height(16.dp))
        Button(onClick = { busy = true; err = null; vm.setup(url, key) { e -> busy = false; err = e } }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Checking…" else "Connect") }
    }
}

@Composable fun MainScreen(vm: MainViewModel, st: UiState) {
    var tab by remember { mutableIntStateOf(0) }
    val ctx = LocalContext.current
    var dismissed by remember { mutableStateOf(false) }
    val u = st.update
    val newer = u != null && u.available && (if (u.versionCode.int() > 0) u.versionCode.int() > BuildConfig.VERSION_CODE else u.versionName != BuildConfig.VERSION_NAME)
    if (newer && u != null && !dismissed) {
        val mandatory = u.mandatory.bool()
        AlertDialog(
            onDismissRequest = { if (!mandatory) dismissed = true },
            title = { Text("Update ${u.versionName ?: ""}") },
            text = { Column { Text(u.notes ?: "A new version is available."); st.updateMessage?.let { Spacer(Modifier.height(8.dp)); Text(it, color = Cyan) } } },
            confirmButton = { TextButton({ vm.installUpdate(ctx) }) { Text("Update") } },
            dismissButton = { if (!mandatory) TextButton({ dismissed = true }) { Text("Later") } },
        )
    }
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("🏠" to "Home", "🌐" to "Servers", "📢" to "Ads", "⚽" to "Sports", "📝" to "Notes").forEachIndexed { i, (g, l) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(g) }, label = { Text(l) })
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(vm, st, newer && u != null)
                1 -> ServersScreen(vm, st)
                2 -> AdsScreen(st)
                3 -> SportsScreen(st)
                else -> NotesScreen(st)
            }
            if (st.loading) LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
        }
    }
}

@Composable fun VideoPlayer(url: String, modifier: Modifier = Modifier, muted: Boolean = false) {
    val ctx = LocalContext.current
    val exo = remember(url) { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(url)); volume = if (muted) 0f else 1f; prepare(); playWhenReady = true } }
    DisposableEffect(exo) { onDispose { exo.release() } }
    AndroidView(factory = { c -> PlayerView(c).also { v -> v.player = exo } }, modifier = modifier)
}

@Composable fun HomeScreen(vm: MainViewModel, st: UiState, updateAvailable: Boolean) {
    val ctx = LocalContext.current; val c = st.config
    var intro by remember { mutableStateOf(false) }
    val imgAds = st.ads.filter { it.type == "image" }
    var idx by remember { mutableIntStateOf(0) }
    LaunchedEffect(imgAds.size) { while (imgAds.isNotEmpty()) { delay(((imgAds[idx % imgAds.size].durationSeconds.int()).takeIf { it > 0 } ?: 8) * 1000L); idx++ } }
    Box(Modifier.fillMaxSize()) {
        c?.backgroundUrl?.let { AsyncImage(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        Box(Modifier.fillMaxSize().background(Color(0xCC0B0C14)))
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            c?.logoUrl?.let { AsyncImage(it, null, Modifier.size(120.dp).clip(MaterialTheme.shapes.large), contentScale = ContentScale.Fit) }
            Spacer(Modifier.height(12.dp))
            Text(c?.name ?: "—", style = MaterialTheme.typography.headlineMedium)
            Text("Version ${BuildConfig.VERSION_NAME}", color = Color(0xFF8A90B0))
            st.error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = Color(0xFFEF4444)) }
            if (updateAvailable) { Spacer(Modifier.height(8.dp)); Text("An update is available", color = Cyan) }
            Spacer(Modifier.height(16.dp))
            if (imgAds.isNotEmpty()) {
                val ad = imgAds[idx % imgAds.size]
                AsyncImage(ad.url, ad.title, Modifier.fillMaxWidth().height(180.dp).clip(MaterialTheme.shapes.medium).clickable { openUrl(ctx, ad.url) }, contentScale = ContentScale.Crop)
                Spacer(Modifier.height(16.dp))
            }
            if (intro && c?.introVideoUrl != null) { VideoPlayer(c.introVideoUrl!!, Modifier.fillMaxWidth().height(220.dp)); Spacer(Modifier.height(12.dp)) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (c?.introVideoUrl != null) OutlinedButton({ intro = !intro }) { Text(if (intro) "Hide intro" else "Play intro") }
                c?.rateUrl?.let { r -> Button({ openUrl(ctx, r) }) { Text("Rate app") } }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton({ vm.refresh() }) { Text("Refresh") }
                TextButton({ vm.logout() }) { Text("Disconnect") }
            }
        }
    }
}

@Composable fun ServersScreen(vm: MainViewModel, st: UiState) {
    if (st.dns.isEmpty()) { Empty("No servers configured."); return }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(st.dns) { d ->
            val selected = st.selectedDns == d.url
            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(d.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        if (d.isDefault.bool()) Text("default", color = Cyan)
                        if (selected) Text("  ✓ selected", color = Purple)
                    }
                    Text(d.url, color = Color(0xFF8A90B0), style = MaterialTheme.typography.bodySmall)
                    d.description?.takeIf { it.isNotBlank() }?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton({ vm.ping(d.url) }) { Text("Test") }
                        TextButton({ vm.selectDns(d.url) }) { Text(if (selected) "Selected" else "Use") }
                        st.latency[d.url]?.let { Text(if (it < 0) "unreachable" else "$it ms", color = if (it < 0) Color(0xFFEF4444) else Color(0xFF22C55E)) }
                    }
                }
            }
        }
    }
}

@Composable fun AdsScreen(st: UiState) {
    val ctx = LocalContext.current
    if (st.ads.isEmpty()) { Empty("No advertisements right now."); return }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(st.ads) { ad ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(ad.title, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    when (ad.type) {
                        "image" -> AsyncImage(ad.url, ad.title, Modifier.fillMaxWidth().height(180.dp).clip(MaterialTheme.shapes.medium).clickable { openUrl(ctx, ad.url) }, contentScale = ContentScale.Crop)
                        "video" -> VideoPlayer(ad.url, Modifier.fillMaxWidth().height(200.dp), muted = true)
                        else -> TextButton({ openUrl(ctx, ad.url) }) { Text("Open") }
                    }
                }
            }
        }
    }
}

@Composable fun SportsScreen(st: UiState) {
    val ctx = LocalContext.current; val s = st.sports
    val links = s?.links ?: emptyList()
    if (links.isEmpty()) { Empty("No sports links."); return }
    fun col(h: String?, d: Color) = runCatching { Color(android.graphics.Color.parseColor(h)) }.getOrDefault(d)
    val border = col(s?.settings?.border, Purple); val bgc = col(s?.settings?.background, Panel); val txt = col(s?.settings?.text, Color.White)
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text(s?.settings?.header ?: "Sports", style = MaterialTheme.typography.headlineSmall) }
        items(links) { l ->
            Box(Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium).background(bgc).clickable { openUrl(ctx, l.url) }.padding(14.dp)) {
                Column { Text(l.title, color = txt, style = MaterialTheme.typography.titleMedium); l.category?.let { Text(it, color = border) } }
            }
        }
    }
}

@Composable fun NotesScreen(st: UiState) {
    if (st.notes.isEmpty()) { Empty("No notes."); return }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(st.notes) { n ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text((if (n.isPinned.bool()) "📌 " else "") + n.title, style = MaterialTheme.typography.titleMedium)
                    n.category?.let { Text(it, color = Cyan, style = MaterialTheme.typography.bodySmall) }
                    n.body?.let { Spacer(Modifier.height(6.dp)); Text(it) }
                }
            }
        }
    }
}

@Composable fun Empty(msg: String) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(msg, color = Color(0xFF8A90B0)) } }
