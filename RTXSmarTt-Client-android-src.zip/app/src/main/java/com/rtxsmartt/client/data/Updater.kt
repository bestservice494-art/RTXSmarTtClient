package com.rtxsmartt.client.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.security.MessageDigest

object Updater {
    /** Downloads with the API key, verifies SHA-256 and package name, then hands over to the system installer. Returns an error text or null. */
    suspend fun downloadAndInstall(ctx: Context, http: OkHttpClient, key: String, u: UpdateDto): String? = withContext(Dispatchers.IO) {
        val url = u.downloadUrl ?: return@withContext "No download URL"
        val expected = u.sha256?.lowercase() ?: return@withContext "Server did not provide a checksum; refusing to install"
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return@withContext "Allow installs from this app, then press Update again"
        }
        val dir = File(ctx.cacheDir, "updates").apply { mkdirs() }
        val file = File(dir, "update.apk")
        try {
            val req = Request.Builder().url(url).header("Authorization", "Bearer $key").build()
            val md = MessageDigest.getInstance("SHA-256")
            http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) return@withContext "Download failed (${r.code})"
                r.body!!.byteStream().use { input -> file.outputStream().use { out ->
                    val buf = ByteArray(65536); var n: Int
                    while (input.read(buf).also { n = it } > 0) { md.update(buf, 0, n); out.write(buf, 0, n) }
                } }
            }
            val got = md.digest().joinToString("") { "%02x".format(it) }
            if (got != expected) { file.delete(); return@withContext "Checksum mismatch; file discarded" }
            val info = ctx.packageManager.getPackageArchiveInfo(file.path, 0)
            if (info == null || info.packageName != ctx.packageName) { file.delete(); return@withContext "The downloaded file is not an update of this app" }
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
            ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
            null
        } catch (e: Exception) { file.delete(); "Update failed: ${e.message}" }
    }
}
