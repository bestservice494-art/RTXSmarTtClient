# RTXSmarTt Client (Android, Kotlin + Jetpack Compose)

Native client for **RTXSmarTt PRO** (REST v1). STATUS: source written, **not compiled or tested yet** (no Android SDK in the authoring environment). Expect small build fixes on the first run.

## What it does
Connects with *panel URL + API key* (API Management -> Create credential; the key is stored encrypted with the Android Keystore). Screens: Home (logo, background, rotating image ads, intro video, rate button), Servers (DNS list, latency test, choose one), Ads (image/video/link), Sports (colors from Sports Display), Notes. Updates: reads `/updates/latest`, downloads with the key, verifies SHA-256 **and** package name, then opens the system installer.

## Build without a computer (GitHub Actions)
1. Create a private GitHub repo, upload the contents of this folder (keep `.github/`).
2. Actions tab -> "Build APK" -> Run workflow -> download the artifact `RTXSmarTtClient-debug-apk`.
3. Build locally instead: Android Studio -> open folder -> Run, or `gradle :app:assembleDebug`.

## Signing & updates (important)
Debug builds are signed with a throw-away key, so a later build cannot be installed over an earlier one. For real updates create ONE release keystore, keep it safe, add repo secrets and extend the workflow to export `RTX_KEYSTORE_FILE`, `RTX_KEYSTORE_PASSWORD`, `RTX_KEY_ALIAS`, `RTX_KEY_PASSWORD`, then run `gradle :app:assembleRelease`.
Upload each release APK in the panel (APK Updates), with this app's package `com.rtxsmartt.client`, then press "Make current".

## Security notes
HTTPS only (cleartext disabled). The API key is read-only scope. Revoke it in the panel if a phone is lost.
